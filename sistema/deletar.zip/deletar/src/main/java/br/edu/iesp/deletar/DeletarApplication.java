package br.edu.iesp.deletar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeletarApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeletarApplication.class, args);
	}

}
