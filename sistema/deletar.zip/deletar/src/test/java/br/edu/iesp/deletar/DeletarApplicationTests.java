package br.edu.iesp.deletar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeletarApplicationTests {

	@Test
	void contextLoads() {
	}

}
